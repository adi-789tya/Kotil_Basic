package com.shivam.cookwithme.data

val LEFT_LINK: String = "https://recipesapi.herokuapp.com/api/search?q="
val QUERY: String = "&q="