# Cook #WithMe
Kotlin Android Application developed during #30DaysOfKotlin by Shivam

--------------

A simple ingredient recipe finder android application developed with Kotlin, while exploring and learning it.

This app having access/ permission to use the INTERNET makes a API (GET) request to https://recipesapi.herokuapp.com to fetch relevant recipes (top rated socially) in the form of JSON data using Google's Volley Library. The app also has implementation of constrained layout, CardView, ListView, application widgets and a splash screen. 

Follow me on Instagram [@ShivamCodes](https://instagram.com/shivamcodes) to see my #30DaysOfCode journey.